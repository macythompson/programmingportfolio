import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Calculator extends PApplet {

Button[] buttons = new Button[22];
String displayVal = "0.0";
String op = ""; // operator to use in a calculation
boolean left = true;
float r = 0.0f; //what is right of the operator
float l = 0.0f; //what is left of the operator
float result = 0.0f; //the answer
int currentNum = 0;

public void setup() {
  
  displayVal = "0";
  op = "";
  left = true;
  r = 0.0f;
  l = 0.0f;
  result = 0.0f;
  buttons[0] = new Button(30, 75, 45, 45, "  +/-", false);
  buttons[1] = new Button(140, 140, 80, 80, "8", true);
  buttons[2] = new Button(260, 140, 80, 80, "9", true);
  buttons[3] = new Button(20, 240, 80, 80, "4", true);
  buttons[4] = new Button(140, 240, 80, 80, "5", true);
  buttons[5] = new Button(260, 240, 80, 80, "6", true);
  buttons[6] = new Button(20, 340, 80, 80, "1", true);
  buttons[7] = new Button(140, 340, 80, 80, "2", true);
  buttons[8] = new Button(260, 340, 80, 80, "3", true);
  buttons[9] = new Button(20, 440, 80, 80, "0", true);
  buttons[10] = new Button(380, 440, 80, 80, "÷", false);
  buttons[11] = new Button(380, 340, 80, 80, "*", false);
  buttons[12] = new Button(380, 240, 80, 80, "-", false);
  buttons[13] = new Button(380, 140, 80, 80, "+", false);
  buttons[14] = new Button(140, 440, 80, 80, ".", false);
  buttons[15] = new Button(260, 440, 80, 80, "x²", false);
  buttons[16] = new Button(380, 540, 80, 80, "=", false);
  buttons[17] = new Button(260, 540, 80, 80, "√", false);
  buttons[18] = new Button(140, 540, 80, 80, "cos", false);
  buttons[19] = new Button(20, 540, 80, 80, "sin", false);
  buttons[20] = new Button(30, 15, 45, 45, "C", false);
  buttons[21] = new Button(20, 140, 80, 80, "7", true);
}
public void draw() {
  background(127);
  for (int i=0; i<buttons.length; i++) {
    buttons[i].display();
    buttons[i].hover();
  }
  updateDisplay();
}
public void updateDisplay() {
  rectMode(CORNER);
  fill(255);
  rect(115, 35, 330, 70, 15);
  fill(0);
  rect(120, 40, 320, 60, 15);
  textSize(20);
  fill(255);

  //Render Scaling Text
  if (displayVal.length()<13) {
    textSize(32);
  } else if (displayVal.length()<14) {
    textSize(28);
  } else if (displayVal.length()<15) {
    textSize(26);
  } else if (displayVal.length()<17) {
    textSize(24);
  } else if (displayVal.length()<19) {
    textSize(22);
  } else if (displayVal.length()<21) {
    textSize(20);
  } else if (displayVal.length()<23) {
    textSize(18);
  } else if (displayVal.length()<25) {
    textSize(16);
  } else {
    textSize(14);
  }
  textAlign(RIGHT);
  text(displayVal, width - 80, 80);
}

public void mouseReleased() {
  println("L:" + l + "R:" + r + "Op:" + op);
  println("Result:" + result + "Left:" +left);
  for (int i=0; i<buttons.length; i++) {
    if (buttons[i].hover && displayVal.length()<20) {
      handleEvent(buttons[i].val, true);
    }
  }
}
public void keyPressed() {
  println("KEY:" + key + "keyCode:" + keyCode);

  if (key == '0') {
    handleEvent("0", true);
  } else if (key == '1') {
    handleEvent("1", true);
  } else if (key == '2') {
    handleEvent("2", true);
  } else if (key == '3') {
    handleEvent("3", true);
  } else if (key == '4') {
    handleEvent("4", true);
  } else if (key == '5') {
    handleEvent("5", true);
  } else if (key == '6') {
    handleEvent("6", true);
  } else if (key == '7') {
    handleEvent("7", true);
  } else if (key == '8') {
    handleEvent("8", true);
  } else if (key == '9') {
    handleEvent("9", true);
  } else if (key == '+') {
    handleEvent("+", false);
  } else if (key == '-') {
    handleEvent("-", false);
  } else if (key == '*') {
    handleEvent("*", false);
  } else if (key == '/') {
    handleEvent("÷", false);
  } else if (key == '.') {
    handleEvent(".", false);
  } else if (key == 27 || key == 'C') {
    handleEvent("C", false);
  } else if (key == 10) //(key == CODED) {
    if (keyCode == ENTER || keyCode == RETURN) {
      handleEvent("=", false);
    }
}

public String handleEvent(String val, boolean num) {
  if (left & num) { //Left Number
    if (displayVal.equals("0") || result == 1) {
      displayVal = (val);
      l = PApplet.parseFloat(displayVal);
    } else {
      displayVal += (val);
      l = PApplet.parseFloat(displayVal);
    }
  } else if (!left && num) {
    if (displayVal.equals("=") || result == 1) {
      displayVal = (val);
      r = PApplet.parseFloat(displayVal);
    } else {
      displayVal += (val);
      r = PApplet.parseFloat(displayVal);
    }
  } else if (val.equals("C")) {
    displayVal = "0";
    result = 0.0f;
    left = true;
    r = 0.0f;
    l = 0.0f;
    op = "";
  } else if (val.equals("+")) {
  }
  return val;
}

public void performCalulation() {
  if (op.equals("+")) {
    result = l + r;
  } else if (op.equals ("-")) {
    result = l - r;
  } else if (op.equals ("*")) {
    result = l * r;
  } else if (op.equals ("÷")) {
    result = l / r;
  }
  l = result;
  displayVal = str(result);
  left = true;
}
class Button {
  // Member Variable
  int x, y, w, h;
  int c1, c2, c3, c4;
  String val;
  boolean hover;
  boolean numButton;

  // Constructor
  Button(int tempX, int tempY, int tempW, int tempH, String tempVal, boolean numButton) {
    x = tempX;
    y = tempY;
    w = tempW;
    h = tempH;
    c1 = 0xffffc905;
    c2 = 0xffffb405;
    c3 = 0xffabb3db;
    c4 = 0xff8190db;
    val = tempVal;
    hover = false;
    this.numButton = numButton;
  }

  // Display Method
  public void display() {
    textSize(15);
    textAlign(CENTER);
    if (numButton) { 
      if (hover) {
        fill(c2);
      } else {
        fill(c1);
      }
    }else {
      if (hover) {
        fill(c3);
      } else {
        fill(c4);
      }
    }
    rect(x, y, w, h);
    fill(0);
    text(val, x+10, y+30);
  } 

  // Hover Method
  public void hover() {
    hover = (mouseX>x && mouseY>y && mouseX<x+w && mouseY<y+h);
  }
}
  public void settings() {  size(480, 640); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Calculator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
